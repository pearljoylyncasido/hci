document.addEventListener('DOMContentLoaded', () => {
    // Initialize comment section for the existing post
    const existingPost = document.querySelector('.discussion-post');
    if (existingPost) {
        initializeCommentSection(existingPost);
    }

    // Initialize comment section for posts
    const initializeCommentSection = (postElement) => {
        const commentBtn = postElement.querySelector('.comment-btn');
        const commentBox = postElement.querySelector('.comment-box');
        const commentsList = postElement.querySelector('.comments-list');
        const commentCount = postElement.querySelector('.post-stats span:nth-child(2)');

        commentBtn.addEventListener('click', () => {
            const commentText = commentBox.value.trim();
            if (!commentText) {
                alert('Please write a comment before submitting!');
                return;
            }

            const comment = document.createElement('div');
            comment.classList.add('comment');
            comment.innerHTML = `
                <p><strong>You:</strong> ${commentText}</p>
            `;

            commentsList.appendChild(comment);
            commentBox.value = '';

            // Update comment count
            let currentCount = parseInt(commentCount.textContent.match(/\d+/)[0]) || 0;
            commentCount.innerHTML = `<i class="fas fa-comment"></i> ${currentCount + 1} Comments`;
        });
    };
});